
ScrollReveal({ reset: true }).reveal('.scroll-reveal', {
  distance: '50px',
  duration: 1000,
  easing: 'ease-in-out',
  origin: 'bottom',
  interval: 200
});
